using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using UiPath.CodedWorkflows;
using UiPath.CodedWorkflows.Interfaces;
using UiPath.Activities.Contracts;
using client_p001_process_name;

[assembly: WorkflowRunnerServiceAttribute(typeof(client_p001_process_name.WorkflowRunnerService))]
namespace client_p001_process_name
{
    public class WorkflowRunnerService
    {
        private readonly ICodedWorkflowServices _services;
        public WorkflowRunnerService(ICodedWorkflowServices services)
        {
            _services = services;
        }

        /// <summary>
        /// Invokes the wfs/ACME/acme_login.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void acme_login(System.Collections.Generic.Dictionary<string, object> _dicConfig, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\ACME\acme_login.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig } }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/ACME/acme_login.xaml
        /// </summary>
        public void acme_login(System.Collections.Generic.Dictionary<string, object> _dicConfig)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\ACME\acme_login.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig } }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/ACME/acme_logout.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void acme_logout(System.Collections.Generic.Dictionary<string, object> _dicConfig, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\ACME\acme_logout.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig } }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/ACME/acme_logout.xaml
        /// </summary>
        public void acme_logout(System.Collections.Generic.Dictionary<string, object> _dicConfig)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\ACME\acme_logout.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig } }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_utils/chrome_save_file_as.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public bool chrome_save_file_as(string _strFilePath, int _intWaitingSeconds, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_utils\chrome_save_file_as.xaml", new Dictionary<string, object> { { "_strFilePath", _strFilePath }, { "_intWaitingSeconds", _intWaitingSeconds } }, default, isolated, default, GetAssemblyName());
            return (bool)result["_boolFileDownloaded"];
        }

        /// <summary>
        /// Invokes the wfs/_utils/chrome_save_file_as.xaml
        /// </summary>
        public bool chrome_save_file_as(string _strFilePath, int _intWaitingSeconds)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_utils\chrome_save_file_as.xaml", new Dictionary<string, object> { { "_strFilePath", _strFilePath }, { "_intWaitingSeconds", _intWaitingSeconds } }, default, default, default, GetAssemblyName());
            return (bool)result["_boolFileDownloaded"];
        }

        /// <summary>
        /// Invokes the wfs/_utils/excel_execute_macro.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void excel_execute_macro(string _strExcelFilePath, string _strMacroFunctionName, string _strMacroFilePath, object[] _arrMacroArguments, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_utils\excel_execute_macro.xaml", new Dictionary<string, object> { { "_strExcelFilePath", _strExcelFilePath }, { "_strMacroFunctionName", _strMacroFunctionName }, { "_strMacroFilePath", _strMacroFilePath }, { "_arrMacroArguments", _arrMacroArguments } }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_utils/excel_execute_macro.xaml
        /// </summary>
        public void excel_execute_macro(string _strExcelFilePath, string _strMacroFunctionName, string _strMacroFilePath, object[] _arrMacroArguments)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_utils\excel_execute_macro.xaml", new Dictionary<string, object> { { "_strExcelFilePath", _strExcelFilePath }, { "_strMacroFunctionName", _strMacroFunctionName }, { "_strMacroFilePath", _strMacroFilePath }, { "_arrMacroArguments", _arrMacroArguments } }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_fmw/memory/fmw_concat_process_memory.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public (System.Data.DataTable _dtaMemory, string[] _arrMemoryFiles) fmw_concat_process_memory(System.Collections.Generic.Dictionary<string, object> _dicConfig, int _intExecutionDayOffset, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\memory\fmw_concat_process_memory.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig }, { "_intExecutionDayOffset", _intExecutionDayOffset } }, default, isolated, default, GetAssemblyName());
            return ((System.Data.DataTable)result["_dtaMemory"], (string[])result["_arrMemoryFiles"]);
        }

        /// <summary>
        /// Invokes the wfs/_fmw/memory/fmw_concat_process_memory.xaml
        /// </summary>
        public (System.Data.DataTable _dtaMemory, string[] _arrMemoryFiles) fmw_concat_process_memory(System.Collections.Generic.Dictionary<string, object> _dicConfig, int _intExecutionDayOffset)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\memory\fmw_concat_process_memory.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig }, { "_intExecutionDayOffset", _intExecutionDayOffset } }, default, default, default, GetAssemblyName());
            return ((System.Data.DataTable)result["_dtaMemory"], (string[])result["_arrMemoryFiles"]);
        }

        /// <summary>
        /// Invokes the wfs/_fmw/memory/fmw_download_process_memory_orch.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void fmw_download_process_memory_orch(System.Collections.Generic.Dictionary<string, object> _dicConfig, int _intExecutionDayOffset, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\memory\fmw_download_process_memory_orch.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig }, { "_intExecutionDayOffset", _intExecutionDayOffset } }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_fmw/memory/fmw_download_process_memory_orch.xaml
        /// </summary>
        public void fmw_download_process_memory_orch(System.Collections.Generic.Dictionary<string, object> _dicConfig, int _intExecutionDayOffset)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\memory\fmw_download_process_memory_orch.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig }, { "_intExecutionDayOffset", _intExecutionDayOffset } }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_fmw/fmw_send_email.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void fmw_send_email(string _strSubject, string[] _arrBodyFields, string[] _arrRecipients, string _strSenderName, string[] _arrAttachmentsFiles, string _strEmailWrapperFile, string _strBodyMsgFile, string[] _arrExtraWrapperFields, int _intMaxTimeToSendEmail, string[] _arrRecipientsCC, string _strRecipientsColumn, System.Collections.Generic.Dictionary<string, object> _dicConfig, bool _boolSendToClient, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\fmw_send_email.xaml", new Dictionary<string, object> { { "_strSubject", _strSubject }, { "_arrBodyFields", _arrBodyFields }, { "_arrRecipients", _arrRecipients }, { "_strSenderName", _strSenderName }, { "_arrAttachmentsFiles", _arrAttachmentsFiles }, { "_strEmailWrapperFile", _strEmailWrapperFile }, { "_strBodyMsgFile", _strBodyMsgFile }, { "_arrExtraWrapperFields", _arrExtraWrapperFields }, { "_intMaxTimeToSendEmail", _intMaxTimeToSendEmail }, { "_arrRecipientsCC", _arrRecipientsCC }, { "_strRecipientsColumn", _strRecipientsColumn }, { "_dicConfig", _dicConfig }, { "_boolSendToClient", _boolSendToClient } }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_fmw/fmw_send_email.xaml
        /// </summary>
        public void fmw_send_email(string _strSubject, string[] _arrBodyFields, string[] _arrRecipients, string _strSenderName, string[] _arrAttachmentsFiles, string _strEmailWrapperFile, string _strBodyMsgFile, string[] _arrExtraWrapperFields, int _intMaxTimeToSendEmail, string[] _arrRecipientsCC, string _strRecipientsColumn, System.Collections.Generic.Dictionary<string, object> _dicConfig, bool _boolSendToClient)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\fmw_send_email.xaml", new Dictionary<string, object> { { "_strSubject", _strSubject }, { "_arrBodyFields", _arrBodyFields }, { "_arrRecipients", _arrRecipients }, { "_strSenderName", _strSenderName }, { "_arrAttachmentsFiles", _arrAttachmentsFiles }, { "_strEmailWrapperFile", _strEmailWrapperFile }, { "_strBodyMsgFile", _strBodyMsgFile }, { "_arrExtraWrapperFields", _arrExtraWrapperFields }, { "_intMaxTimeToSendEmail", _intMaxTimeToSendEmail }, { "_arrRecipientsCC", _arrRecipientsCC }, { "_strRecipientsColumn", _strRecipientsColumn }, { "_dicConfig", _dicConfig }, { "_boolSendToClient", _boolSendToClient } }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_fmw/memory/fmw_update_process_memory.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void fmw_update_process_memory(System.Collections.Generic.Dictionary<string, object> _dicConfig, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\memory\fmw_update_process_memory.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig } }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_fmw/memory/fmw_update_process_memory.xaml
        /// </summary>
        public void fmw_update_process_memory(System.Collections.Generic.Dictionary<string, object> _dicConfig)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\memory\fmw_update_process_memory.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig } }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_fmw/memory/fmw_upload_process_memory.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void fmw_upload_process_memory(System.Collections.Generic.Dictionary<string, object> _dicConfig, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\memory\fmw_upload_process_memory.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig } }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_fmw/memory/fmw_upload_process_memory.xaml
        /// </summary>
        public void fmw_upload_process_memory(System.Collections.Generic.Dictionary<string, object> _dicConfig)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\memory\fmw_upload_process_memory.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig } }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the main.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void main(int _intRobotState, int _intFinalState, bool _boolSendToClient, int _intExecutionDayOffset, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"main.xaml", new Dictionary<string, object> { { "_intRobotState", _intRobotState }, { "_intFinalState", _intFinalState }, { "_boolSendToClient", _boolSendToClient }, { "_intExecutionDayOffset", _intExecutionDayOffset } }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the main.xaml
        /// </summary>
        public void main(int _intRobotState, int _intFinalState, bool _boolSendToClient, int _intExecutionDayOffset)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"main.xaml", new Dictionary<string, object> { { "_intRobotState", _intRobotState }, { "_intFinalState", _intFinalState }, { "_boolSendToClient", _boolSendToClient }, { "_intExecutionDayOffset", _intExecutionDayOffset } }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_fmw/office365_send_email.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void office365_send_email(string _strEmailAddress, string _strTenantId, string _strAppId, string _strSubject, string[] _arrAttachmentsFiles, string _strEmailBody, string[] _arrTo, string[] _arrCc, string[] _arrBcc, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\office365_send_email.xaml", new Dictionary<string, object> { { "_strEmailAddress", _strEmailAddress }, { "_strTenantId", _strTenantId }, { "_strAppId", _strAppId }, { "_strSubject", _strSubject }, { "_arrAttachmentsFiles", _arrAttachmentsFiles }, { "_strEmailBody", _strEmailBody }, { "_arrTo", _arrTo }, { "_arrCc", _arrCc }, { "_arrBcc", _arrBcc } }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_fmw/office365_send_email.xaml
        /// </summary>
        public void office365_send_email(string _strEmailAddress, string _strTenantId, string _strAppId, string _strSubject, string[] _arrAttachmentsFiles, string _strEmailBody, string[] _arrTo, string[] _arrCc, string[] _arrBcc)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\office365_send_email.xaml", new Dictionary<string, object> { { "_strEmailAddress", _strEmailAddress }, { "_strTenantId", _strTenantId }, { "_strAppId", _strAppId }, { "_strSubject", _strSubject }, { "_arrAttachmentsFiles", _arrAttachmentsFiles }, { "_strEmailBody", _strEmailBody }, { "_arrTo", _arrTo }, { "_arrCc", _arrCc }, { "_arrBcc", _arrBcc } }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_templates/p001_build_worktray.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void p001_build_worktray(System.Collections.Generic.Dictionary<string, object> _dicConfig, int _intExecutionDayOffset, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_templates\p001_build_worktray.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig }, { "_intExecutionDayOffset", _intExecutionDayOffset } }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_templates/p001_build_worktray.xaml
        /// </summary>
        public void p001_build_worktray(System.Collections.Generic.Dictionary<string, object> _dicConfig, int _intExecutionDayOffset)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_templates\p001_build_worktray.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig }, { "_intExecutionDayOffset", _intExecutionDayOffset } }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_templates/p001_main_state_wf_2.0.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void p001_main_state_wf_2_0(System.Collections.Generic.Dictionary<string, object> _dicConfig, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_templates\p001_main_state_wf_2.0.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig } }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_templates/p001_main_state_wf_2.0.xaml
        /// </summary>
        public void p001_main_state_wf_2_0(System.Collections.Generic.Dictionary<string, object> _dicConfig)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_templates\p001_main_state_wf_2.0.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig } }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_templates/p001_main_state_wf_old.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void p001_main_state_wf_old(System.Collections.Generic.Dictionary<string, object> _dicConfig, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_templates\p001_main_state_wf_old.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig } }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_templates/p001_main_state_wf_old.xaml
        /// </summary>
        public void p001_main_state_wf_old(System.Collections.Generic.Dictionary<string, object> _dicConfig)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_templates\p001_main_state_wf_old.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig } }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_templates/p001_send_execution_report.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void p001_send_execution_report(System.Collections.Generic.Dictionary<string, object> _dicConfig, bool _boolSendToClient, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_templates\p001_send_execution_report.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig }, { "_boolSendToClient", _boolSendToClient } }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_templates/p001_send_execution_report.xaml
        /// </summary>
        public void p001_send_execution_report(System.Collections.Generic.Dictionary<string, object> _dicConfig, bool _boolSendToClient)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_templates\p001_send_execution_report.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig }, { "_boolSendToClient", _boolSendToClient } }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_templates/process_row_template.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void process_row_template(System.Collections.Generic.Dictionary<string, object> _dicConfig, System.Data.DataRow _drowWt, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_templates\process_row_template.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig }, { "_drowWt", _drowWt } }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_templates/process_row_template.xaml
        /// </summary>
        public void process_row_template(System.Collections.Generic.Dictionary<string, object> _dicConfig, System.Data.DataRow _drowWt)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_templates\process_row_template.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig }, { "_drowWt", _drowWt } }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_fmw/save_exception_screenshot.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void save_exception_screenshot(System.Collections.Generic.Dictionary<string, object> _dicConfig, int _intRowIdx, string _strExcType, int _intTry, bool _boolSaveScreenshot, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\save_exception_screenshot.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig }, { "_intRowIdx", _intRowIdx }, { "_strExcType", _strExcType }, { "_intTry", _intTry }, { "_boolSaveScreenshot", _boolSaveScreenshot } }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_fmw/save_exception_screenshot.xaml
        /// </summary>
        public void save_exception_screenshot(System.Collections.Generic.Dictionary<string, object> _dicConfig, int _intRowIdx, string _strExcType, int _intTry, bool _boolSaveScreenshot)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\save_exception_screenshot.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig }, { "_intRowIdx", _intRowIdx }, { "_strExcType", _strExcType }, { "_intTry", _intTry }, { "_boolSaveScreenshot", _boolSaveScreenshot } }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_test/test_wf.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void test_wf(System.Collections.Generic.Dictionary<string, object> _dicConfig, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_test\test_wf.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig } }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_test/test_wf.xaml
        /// </summary>
        public void test_wf(System.Collections.Generic.Dictionary<string, object> _dicConfig)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_test\test_wf.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig } }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_utils/utils_clean_folder.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void utils_clean_folder(string _strFolderToClean, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_utils\utils_clean_folder.xaml", new Dictionary<string, object> { { "_strFolderToClean", _strFolderToClean } }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_utils/utils_clean_folder.xaml
        /// </summary>
        public void utils_clean_folder(string _strFolderToClean)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_utils\utils_clean_folder.xaml", new Dictionary<string, object> { { "_strFolderToClean", _strFolderToClean } }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_fmw/utils_close_apps.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void utils_close_apps(System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\utils_close_apps.xaml", new Dictionary<string, object> { }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_fmw/utils_close_apps.xaml
        /// </summary>
        public void utils_close_apps()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\utils_close_apps.xaml", new Dictionary<string, object> { }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_utils/utils_create_dictionary.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public System.Collections.Generic.Dictionary<string, string> utils_create_dictionary(string _strDictFilePath, string _strKeyColumn, string _strValueColumn, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_utils\utils_create_dictionary.xaml", new Dictionary<string, object> { { "_strDictFilePath", _strDictFilePath }, { "_strKeyColumn", _strKeyColumn }, { "_strValueColumn", _strValueColumn } }, default, isolated, default, GetAssemblyName());
            return (System.Collections.Generic.Dictionary<string, string>)result["_dictOut"];
        }

        /// <summary>
        /// Invokes the wfs/_utils/utils_create_dictionary.xaml
        /// </summary>
        public System.Collections.Generic.Dictionary<string, string> utils_create_dictionary(string _strDictFilePath, string _strKeyColumn, string _strValueColumn)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_utils\utils_create_dictionary.xaml", new Dictionary<string, object> { { "_strDictFilePath", _strDictFilePath }, { "_strKeyColumn", _strKeyColumn }, { "_strValueColumn", _strValueColumn } }, default, default, default, GetAssemblyName());
            return (System.Collections.Generic.Dictionary<string, string>)result["_dictOut"];
        }

        /// <summary>
        /// Invokes the wfs/_fmw/utils_dta_to_html.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public string utils_dta_to_html(System.Data.DataTable _dtaTable, string _strHeaderColor, string _strStripesColor, string _strBorderColor, bool _boolColBorders, int _intTableWidth, string _strFont, string _strHeaderFontColor, string _strFirstColAlignment, string _strColAlignnment, bool _boolCenterTable, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\utils_dta_to_html.xaml", new Dictionary<string, object> { { "_dtaTable", _dtaTable }, { "_strHeaderColor", _strHeaderColor }, { "_strStripesColor", _strStripesColor }, { "_strBorderColor", _strBorderColor }, { "_boolColBorders", _boolColBorders }, { "_intTableWidth", _intTableWidth }, { "_strFont", _strFont }, { "_strHeaderFontColor", _strHeaderFontColor }, { "_strFirstColAlignment", _strFirstColAlignment }, { "_strColAlignnment", _strColAlignnment }, { "_boolCenterTable", _boolCenterTable } }, default, isolated, default, GetAssemblyName());
            return (string)result["_strHtmlTable"];
        }

        /// <summary>
        /// Invokes the wfs/_fmw/utils_dta_to_html.xaml
        /// </summary>
        public string utils_dta_to_html(System.Data.DataTable _dtaTable, string _strHeaderColor, string _strStripesColor, string _strBorderColor, bool _boolColBorders, int _intTableWidth, string _strFont, string _strHeaderFontColor, string _strFirstColAlignment, string _strColAlignnment, bool _boolCenterTable)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\utils_dta_to_html.xaml", new Dictionary<string, object> { { "_dtaTable", _dtaTable }, { "_strHeaderColor", _strHeaderColor }, { "_strStripesColor", _strStripesColor }, { "_strBorderColor", _strBorderColor }, { "_boolColBorders", _boolColBorders }, { "_intTableWidth", _intTableWidth }, { "_strFont", _strFont }, { "_strHeaderFontColor", _strHeaderFontColor }, { "_strFirstColAlignment", _strFirstColAlignment }, { "_strColAlignnment", _strColAlignnment }, { "_boolCenterTable", _boolCenterTable } }, default, default, default, GetAssemblyName());
            return (string)result["_strHtmlTable"];
        }

        /// <summary>
        /// Invokes the wfs/_utils/utils_get_country_working_days.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public System.DateTime[] utils_get_country_working_days(System.DateTime _dtiStartDate, int _intMaxDays, string _strCountryCode, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_utils\utils_get_country_working_days.xaml", new Dictionary<string, object> { { "_dtiStartDate", _dtiStartDate }, { "_intMaxDays", _intMaxDays }, { "_strCountryCode", _strCountryCode } }, default, isolated, default, GetAssemblyName());
            return (System.DateTime[])result["_arrWorkingDays"];
        }

        /// <summary>
        /// Invokes the wfs/_utils/utils_get_country_working_days.xaml
        /// </summary>
        public System.DateTime[] utils_get_country_working_days(System.DateTime _dtiStartDate, int _intMaxDays, string _strCountryCode)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_utils\utils_get_country_working_days.xaml", new Dictionary<string, object> { { "_dtiStartDate", _dtiStartDate }, { "_intMaxDays", _intMaxDays }, { "_strCountryCode", _strCountryCode } }, default, default, default, GetAssemblyName());
            return (System.DateTime[])result["_arrWorkingDays"];
        }

        /// <summary>
        /// Invokes the wfs/_utils/utils_get_holidays_api.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public System.DateTime[] utils_get_holidays_api(System.DateTime _dtiStartDate, string _strCountryCode, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_utils\utils_get_holidays_api.xaml", new Dictionary<string, object> { { "_dtiStartDate", _dtiStartDate }, { "_strCountryCode", _strCountryCode } }, default, isolated, default, GetAssemblyName());
            return (System.DateTime[])result["_arrdtiHolidays"];
        }

        /// <summary>
        /// Invokes the wfs/_utils/utils_get_holidays_api.xaml
        /// </summary>
        public System.DateTime[] utils_get_holidays_api(System.DateTime _dtiStartDate, string _strCountryCode)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_utils\utils_get_holidays_api.xaml", new Dictionary<string, object> { { "_dtiStartDate", _dtiStartDate }, { "_strCountryCode", _strCountryCode } }, default, default, default, GetAssemblyName());
            return (System.DateTime[])result["_arrdtiHolidays"];
        }

        /// <summary>
        /// Invokes the wfs/_fmw/utils_kill_processes.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void utils_kill_processes(string[] _arrProcessesToKill, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\utils_kill_processes.xaml", new Dictionary<string, object> { { "_arrProcessesToKill", _arrProcessesToKill } }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_fmw/utils_kill_processes.xaml
        /// </summary>
        public void utils_kill_processes(string[] _arrProcessesToKill)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\utils_kill_processes.xaml", new Dictionary<string, object> { { "_arrProcessesToKill", _arrProcessesToKill } }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_fmw/utils_read_config_dict.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public System.Collections.Generic.Dictionary<string, object> utils_read_config_dict(string _strConfigFile, string[] _strarrConfigSheets, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\utils_read_config_dict.xaml", new Dictionary<string, object> { { "_strConfigFile", _strConfigFile }, { "_strarrConfigSheets", _strarrConfigSheets } }, default, isolated, default, GetAssemblyName());
            return (System.Collections.Generic.Dictionary<string, object>)result["_dicConfiguration"];
        }

        /// <summary>
        /// Invokes the wfs/_fmw/utils_read_config_dict.xaml
        /// </summary>
        public System.Collections.Generic.Dictionary<string, object> utils_read_config_dict(string _strConfigFile, string[] _strarrConfigSheets)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\utils_read_config_dict.xaml", new Dictionary<string, object> { { "_strConfigFile", _strConfigFile }, { "_strarrConfigSheets", _strarrConfigSheets } }, default, default, default, GetAssemblyName());
            return (System.Collections.Generic.Dictionary<string, object>)result["_dicConfiguration"];
        }

        /// <summary>
        /// Invokes the wfs/_utils/utils_run_python_script.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void utils_run_python_script(string _strPythonScriptPath, string[] _arrScriptArguments, int _intDelaySecsAfterExecution, double _dblExecutionMinutesTimeout, string _strPythonInterpreter, bool _boolRunBatchMinimized, bool _boolWaitScriptFinalization, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_utils\utils_run_python_script.xaml", new Dictionary<string, object> { { "_strPythonScriptPath", _strPythonScriptPath }, { "_arrScriptArguments", _arrScriptArguments }, { "_intDelaySecsAfterExecution", _intDelaySecsAfterExecution }, { "_dblExecutionMinutesTimeout", _dblExecutionMinutesTimeout }, { "_strPythonInterpreter", _strPythonInterpreter }, { "_boolRunBatchMinimized", _boolRunBatchMinimized }, { "_boolWaitScriptFinalization", _boolWaitScriptFinalization } }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_utils/utils_run_python_script.xaml
        /// </summary>
        public void utils_run_python_script(string _strPythonScriptPath, string[] _arrScriptArguments, int _intDelaySecsAfterExecution, double _dblExecutionMinutesTimeout, string _strPythonInterpreter, bool _boolRunBatchMinimized, bool _boolWaitScriptFinalization)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_utils\utils_run_python_script.xaml", new Dictionary<string, object> { { "_strPythonScriptPath", _strPythonScriptPath }, { "_arrScriptArguments", _arrScriptArguments }, { "_intDelaySecsAfterExecution", _intDelaySecsAfterExecution }, { "_dblExecutionMinutesTimeout", _dblExecutionMinutesTimeout }, { "_strPythonInterpreter", _strPythonInterpreter }, { "_boolRunBatchMinimized", _boolRunBatchMinimized }, { "_boolWaitScriptFinalization", _boolWaitScriptFinalization } }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_fmw/utils_take_screenshot.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void utils_take_screenshot(string _strScreenshotPath, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\utils_take_screenshot.xaml", new Dictionary<string, object> { { "_strScreenshotPath", _strScreenshotPath } }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_fmw/utils_take_screenshot.xaml
        /// </summary>
        public void utils_take_screenshot(string _strScreenshotPath)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_fmw\utils_take_screenshot.xaml", new Dictionary<string, object> { { "_strScreenshotPath", _strScreenshotPath } }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_utils/utils_transform_dta_columns.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public System.Data.DataTable utils_transform_dta_columns(string _strTransformColsFile, System.Data.DataTable _dtaIn, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_utils\utils_transform_dta_columns.xaml", new Dictionary<string, object> { { "_strTransformColsFile", _strTransformColsFile }, { "_dtaIn", _dtaIn } }, default, isolated, default, GetAssemblyName());
            return (System.Data.DataTable)result["_dtaOut"];
        }

        /// <summary>
        /// Invokes the wfs/_utils/utils_transform_dta_columns.xaml
        /// </summary>
        public System.Data.DataTable utils_transform_dta_columns(string _strTransformColsFile, System.Data.DataTable _dtaIn)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_utils\utils_transform_dta_columns.xaml", new Dictionary<string, object> { { "_strTransformColsFile", _strTransformColsFile }, { "_dtaIn", _dtaIn } }, default, default, default, GetAssemblyName());
            return (System.Data.DataTable)result["_dtaOut"];
        }

        /// <summary>
        /// Invokes the wfs/_templates/workflow_basic_template.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void wfs__templates_workflow_basic_template(System.Collections.Generic.Dictionary<string, object> _dicConfig, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_templates\workflow_basic_template.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig } }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/_templates/workflow_basic_template.xaml
        /// </summary>
        public void wfs__templates_workflow_basic_template(System.Collections.Generic.Dictionary<string, object> _dicConfig)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\_templates\workflow_basic_template.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig } }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/1_state/Workflow.cs
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void Workflow(System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\1_state\Workflow.cs", new Dictionary<string, object> { }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/1_state/Workflow.cs
        /// </summary>
        public void Workflow()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\1_state\Workflow.cs", new Dictionary<string, object> { }, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/1_state/workflow_basic_template.xaml
        /// </summary>
		/// <param name="isolated">Indicates whether to isolate executions (run them within a different process)</param>
        public void workflow_basic_template(System.Collections.Generic.Dictionary<string, object> _dicConfig, System.Boolean isolated)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\1_state\workflow_basic_template.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig } }, default, isolated, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the wfs/1_state/workflow_basic_template.xaml
        /// </summary>
        public void workflow_basic_template(System.Collections.Generic.Dictionary<string, object> _dicConfig)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"wfs\1_state\workflow_basic_template.xaml", new Dictionary<string, object> { { "_dicConfig", _dicConfig } }, default, default, default, GetAssemblyName());
        }

        private string GetAssemblyName()
        {
            var assemblyProvider = _services.Container.Resolve<ILibraryAssemblyProvider>();
            return assemblyProvider.GetLibraryAssemblyName(GetType().Assembly);
        }
    }
}